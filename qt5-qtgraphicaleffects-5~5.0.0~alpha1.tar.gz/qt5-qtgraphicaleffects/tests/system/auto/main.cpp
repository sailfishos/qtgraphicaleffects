/****************************************************************************
**
** Copyright (C) 2012 Nokia Corporation and/or its subsidiary(-ies).
** Contact: http://www.qt-project.org/
**
** This file is part of the Qt Graphical Effects module.
**
** $QT_BEGIN_LICENSE:LGPL$
** GNU Lesser General Public License Usage
** This file may be used under the terms of the GNU Lesser General Public
** License version 2.1 as published by the Free Software Foundation and
** appearing in the file LICENSE.LGPL included in the packaging of this
** file. Please review the following information to ensure the GNU Lesser
** General Public License version 2.1 requirements will be met:
** http://www.gnu.org/licenses/old-licenses/lgpl-2.1.html.
**
** In addition, as a special exception, Nokia gives you certain additional
** rights. These rights are described in the Nokia Qt LGPL Exception
** version 1.1, included in the file LGPL_EXCEPTION.txt in this package.
**
** GNU General Public License Usage
** Alternatively, this file may be used under the terms of the GNU General
** Public License version 3.0 as published by the Free Software Foundation
** and appearing in the file LICENSE.GPL included in the packaging of this
** file. Please review the following information to ensure the GNU General
** Public License version 3.0 requirements will be met:
** http://www.gnu.org/copyleft/gpl.html.
**
** Other Usage
** Alternatively, this file may be used in accordance with the terms and
** conditions contained in a signed written agreement between you and Nokia.
**
**
**
**
**
**
** $QT_END_LICENSE$
**
****************************************************************************/

#include <QtCore/QCoreApplication>
#include "tst_imagecompare.h"

int main(int argc, char *argv[]){

    QCoreApplication a(argc, argv);

    tst_imagecompare test;

    // Tolerance for pixel ARGB component comparison can be set using command line argument -t with tolerance integer value
    // E.g. [program name] -t [tolerance]
    int tolerance = 0;
    for(int i = 0; i < argc; i++){
        if (strcmp(argv[i], "-t") == 0){
            tolerance = atoi(argv[i+1]);

            // Tolerance arguments are removed from the argument list so the list can be sent to QTestLib
            for(i; i < argc; i++){
                argv[i] = argv[i+2];
            }
            argc -= 2;
            break;
        }
    }
    test.setDiffTolerance(tolerance);

    // To be enabled/uncommented if test result output is needed in XML format
    //QStringList arguments;
    //arguments << " " << "-o" << "results.xml" << "-xml";
    //QTest::qExec(&test, arguments);

    QTest::qExec(&test, argc, argv);

    return 0;
}
